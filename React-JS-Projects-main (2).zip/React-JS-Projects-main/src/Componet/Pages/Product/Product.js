import React from 'react';
import "./Product.css";
export default function Product() {
  return (
   <div>
      Product
   </div>
  )
}