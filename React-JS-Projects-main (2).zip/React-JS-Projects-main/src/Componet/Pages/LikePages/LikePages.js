import React from 'react';
import "./LikePages.css";
function LikePages() {
    return (
        <div>
            LikePages
        </div>
    );
}

export default LikePages;