import React from 'react';
function Accaunt() {
  return (
    <div><h1>Accaunt</h1></div>
  )
}
export default Accaunt;