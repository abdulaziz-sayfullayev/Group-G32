import React, { useContext } from "react";
import "./Home.css";
import Home1Img1 from "./Assets/ImgHome1.png";
import { abdulaz1zbek } from "../../Context/Context";
import KarzinkaImg from "./Assets/shopping-cart-Icon.png";
import { AiFillLike, AiOutlineLike } from "react-icons/ai";
function Home() {
  const { data, CartFunction, LikeFunction } = useContext(abdulaz1zbek)
  return (
    <div className="Home">
      <div className="HomeDiv">
        <div className="HomeDiv1">
          <div className="HomeDiv1Div1">
            <figure>
              <img src={Home1Img1} alt="" />
            </figure>
          </div>
          <div className="HomeDiv1Div2">
            <p>Товар дня</p>
            <div>
              {
                data.map((a) => {
                  return (
                    <div key={a.id}>
                      <img src={a.img} alt="" />
                      <div>
                        <p>{a.name}</p>
                        <div>
                          <span>{a.chegirma}</span>
                          <p>{a.narxi}</p>
                        </div>
                        <p>⭐️(5.0)</p>
                        <button onClick={() => CartFunction(a)}><figure><img src={KarzinkaImg} alt="" /></figure>B корзину</button>
                      </div>
                    </div>
                  )
                })
              }
            </div>
          </div>
        </div>
        <div className="HomeDiv2">
          <div>
            <p>Популярный товар</p>
            <div>
              <div>
                <button>Для детских вещей</button>
                <button>Бирки для одежды</button>
              </div>
              <div>
                Перейти в каталог
              </div>
            </div>
          </div>
        </div>
        <div className="CardSDiv">
          {/* {
            data.map((a) => {
              return (
                <div className="CardSDivDiv" key={a.id}>
                  <div className="CardSDivDivDiv1">
                    <div className="CardSDivDivDiv1Div1">
                      <figure>
                        <img src={a.DastapkaImg} alt="" />
                      </figure>
                      <p>{a.DastapkaText}</p>
                    </div>
                  <div className="CardSDivDivDiv1Div2">
                      <figure>
                        <img src={a.SkidkaImg} alt="" />
                      </figure>
                      <p>{a.FoizCardniTepasi}</p>
                    </div>
                    <div className="BнaличииDiv">
                      <span className="Nuqta">
                        <p></p>
                      </span>
                      <p>B наличии</p>
                    </div>
                    <div>
                      <p onClick={() => LikeFunction(a.id)}>
                        {a.like ? <AiFillLike /> : <AiOutlineLike />}
                      </p>
                    </div>
                  </div>
                  <img src={a.img} alt="" />
                  <div>
                    <p>{a.name}</p>
                    <div>
                      <div>
                        <span>{a.chegirma}</span>
                        <p>{a.narxi}</p>
                        <p>{a.foiz}</p>
                      </div>
                      <div>
                        <select name="abdulaz1zbek4">
                          <option value="">{a.Aтpиbyт1}</option>
                        </select>
                        <select name="abdulaz1zbek5">
                          <option value="">{a.Aтpиbyт2}</option>
                        </select>
                        <button>{a.Купитьводинклик}</button>
                        <button onClick={() => CartFunction(a)}>B корзину</button>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
          } */}






{
            data.map((a) => {
              return (
                <div className="CardSDivDiv" key={a.id}>
                  <div className="CardSDivDivDiv1">
                    {/* <div className="CardSDivDivDiv1Div1">
                      <figure>
                        <img src={a.DastapkaImg} alt="" />
                      </figure>
                      <span>{a.DastapkaText}</span>
                    </div>
                  <div className="CardSDivDivDiv1Div2">
                      <figure>
                        <img src={a.SkidkaImg} alt="" />
                      </figure>
                      <span>{a.FoizCardniTepasi}</span>
                    </div> */}
                    <div className="BнaличииDiv">
                      <span className="Nuqta">
                        <p></p>
                      </span>
                      <p>B наличии</p>
                    </div>
                    <div>
                      <p onClick={() => LikeFunction(a.id)}>
                        {a.like ? <AiFillLike /> : <AiOutlineLike />}
                      </p>
                    </div>
                  </div>
                  <img src={a.img} alt="" />
                  <div>
                    <p>{a.name}</p>
                    <div>
                      <div>
                        <span>{a.chegirma}</span>
                        <p>{a.narxi}</p>
                        <p>{a.foiz}</p>
                      </div>
                      <div>
                        <select name="abdulaz1zbek4">
                          <option value="">{a.Aтpиbyт1}</option>
                        </select>
                        <select name="abdulaz1zbek5">
                          <option value="">{a.Aтpиbyт2}</option>
                        </select>
                        <button>{a.Купитьводинклик}</button>
                        <button onClick={() => CartFunction(a)}>B корзину</button>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
    </div>
  )
}
export default Home;
                    {/* <div className="CardSDivDivDiv1">
                  <div>
                      <figure>
                        <img src={a.SkidkaImg} alt="" />
                      </figure>
                      <span></span>
                      <p>{a.FoizCardniTepasi}</p>
                    </div>
                    <div className="CardSDivDivDiv2">
                      <figure>
                        <img src={a.DastapkaImg} alt="" />
                      </figure>
                      <span></span>
                      <p>{a.DastapkaText}</p>
                    </div>
                    <div>
                      <p>B наличии</p>
                    </div>
                    <div>
                      <p onClick={() => LikeFunction(a.id)}>
                        {a.like ? <AiFillLike /> : <AiOutlineLike />}
                      </p>
                    </div>
                  </div>
                  <img src={a.img} alt="" />
                  <div>
                    <p>{a.name}</p>
                    <div>
                      <div>
                        <span>{a.chegirma}</span>
                        <p>{a.narxi}</p>
                        <p>{a.foiz}</p>
                      </div>
                      <div>
                        <select name="abdulaz1zbek4">
                          <option value="">{a.Aтpиbyт1}</option>
                        </select>
                        <select name="abdulaz1zbek5">
                          <option value="">{a.Aтpиbyт2}</option>
                        </select>
                        <button>{a.Купитьводинклик}</button>
                        <button onClick={() => CartFunction(a)}>B корзину</button>
                      </div>
                    </div>
                  </div> */}