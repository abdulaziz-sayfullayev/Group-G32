import React from 'react';
import "./Shop.css";
function Shop() {
  return (
    <div>
      Shop
    </div>
  )
}
export default Shop;