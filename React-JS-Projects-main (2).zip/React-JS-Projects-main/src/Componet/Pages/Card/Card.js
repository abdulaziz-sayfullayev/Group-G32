import React from 'react';
import "./Card.css";
function Card() {
    return (
        <div>
            Card
        </div>
    )
}
export default Card;