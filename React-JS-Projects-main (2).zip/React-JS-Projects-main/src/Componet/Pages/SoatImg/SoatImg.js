import React from 'react';
function SoatImg() {
  return (
    <div><h1>SoatImg</h1></div>
  )
}
export default SoatImg;