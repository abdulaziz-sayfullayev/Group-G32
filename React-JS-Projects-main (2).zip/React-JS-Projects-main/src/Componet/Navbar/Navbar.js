import React from 'react';
import "./Navbar.css";
import LocationImg from "./Assets/locationNavbar1.svg";
import CallImg from "./Assets/CallNavbar1.svg";
import vkontakte1 from "./Assets/vkontakte1.svg";
import Viber from "./Assets/Viber.svg";
import Telegram from "./Assets/Telegram.svg";
import Instagram from "./Assets/Instagram.svg";
import Logo from "./Assets/Logo.svg";
import Tab from "./Assets/Tab.svg";
import Search from "./Assets/SearchIcons.svg";
import SoatImg from "./Assets/Soat.svg";
import Profil from "./Assets/Profil.svg";
import Like from "./Assets/Like.svg";
import Cart from "./Assets/Cart.svg";
import { NavLink } from 'react-router-dom';
import { useContext } from 'react';
import { abdulaz1zbek } from '../Context/Context';
function Navbar() {
  const { tabs1, setTabs1,cart,data, setData, } = useContext(abdulaz1zbek)
  const Tabs1Function = (index) => {
    setTabs1(index)
  }
  return (
    <div className='Navbar'>
      <div className='Navbar1'>
        <div className='Navbar1Div1'>
          <figure>
            <img src={LocationImg} alt="" />
          </figure>
          <select name="abdulaz1zbek1" id="1">
            <option value="">
              Сургут
            </option>
            <option value="">
              curgtт1
            </option>
            <option value="">
              curgtт2
            </option>
          </select>
        </div>
        <div className='Navbar1Div2'>
          <span>Гайд по биркам</span>
        </div>
        <div className='Navbar1Div3'>
          <span>Бонусная система</span>
        </div>
        <div className='Navbar1Div4'>
          <figure>
            <img src={CallImg} alt="" />
          </figure>
          <span>+7(982)570-40-44</span>
        </div>
        <div className='Navbar1Div5'>
          <figure>
            <img src={vkontakte1} alt="" />
          </figure>
          <figure>
            <img src={Viber} alt="" />
          </figure>
          <figure>
            <img src={Telegram} alt="" />
          </figure>
          <figure>
            <img src={Instagram} alt="" />
          </figure>
        </div>
      </div>
      <div className='LineColor'></div>
      <div className='Navbar2'>
        <div className='Navbar2Div1'>
          <NavLink to={"/"}>
            <figure>
              <img src={Logo} alt="" />
            </figure>
          </NavLink>
        </div>
        <div className='Navbar2Div2'>
          <figure>
            <img src={Tab} alt="" />
          </figure>
          <span>КАТАЛОГ</span>
        </div>
        <div className='Navbar2Div3'>
          <div className='div1'>
            <select name="abdulaz1zbek2" id="2">
              <option value="">
                Категория
              </option>
              <option value="">
                Kaтegorия1
              </option>
              <option value="">
                Kaтegorия2
              </option>
            </select>
          </div>
          <div className='div2'>
            <input type="text" name="abdulaz1zbek3" id="3" placeholder='Поиск товара' />
            <figure>
              <img src={Search} alt="" />
            </figure>
          </div>
          <div className='div3'>
            <div className='div3Div1'>
              <NavLink to={"/soatImg"} className={"NavLinkNavbar NavLink"}>
                <figure>
                  <img src={SoatImg} alt="" />
                </figure>
                <span>Статус заказа</span>
              </NavLink>
            </div>
            <div className='div3Div2'>
              <NavLink to={"/accaunt"} className={"NavLinkNavbar NavLink"}>
                <figure>
                  <img src={Profil} alt="" />
                </figure>
                <span>Войти</span>
              </NavLink>
            </div>
            <div className='div3Div3'>
              <NavLink to={"/like"} className={"NavLinkNavbar NavLink"}>
                <figure>
                  <img src={Like} alt="" />
                </figure>
                <span>Избранное {data.filter((az1zbek)=>az1zbek.like).length}</span>
              </NavLink>
            </div>
            <div className='div3Div4'>
              <NavLink to={"/card"} className={"NavLinkNavbar NavLink"}>
                <figure>
                  <img src={Cart} alt="" />
                </figure>
                <span>Корзина {cart.length}</span>
              </NavLink>
            </div>
          </div>
        </div>
      </div>
      <div className='Navbar3'>
        <div className={tabs1 === 2 ? "None" : "Navbar3Div"}>
          <span id=''>Акции</span>
          <span id='SPANNN'>Контакты</span>
          <span id='SPANNN'>Силиконовые бирки</span>
          <span id='SPANNN'>Инструкции</span>
          <span id='SPANNN'>Тканевые бирки</span>
          <span id='SPANNN'>Принты на одежду</span>
        </div>
        <div className={tabs1 === 1 ? "None" : "Navbar3Div"}>
          <span id=''>Акции</span>
          <span id='SPANNN'>Принты на одежду</span>
          <span id='SPANNN'>Тканевые бирки</span>
          <span id='SPANNN'>Силиконовые бирки</span>
          <span id='SPANNN'>Инструкции</span>
          <span id='SPANNN'>Контакты</span>
        </div>
        <p onClick={() => Tabs1Function(1)} className={tabs1 === 1 ? "None" : "button1"}>{">"}</p>
        <p onClick={() => Tabs1Function(2)} className={tabs1 === 2 ? "None" : "button1"}>{"<"}</p>
      </div>
    </div>
  )
}
export default Navbar;