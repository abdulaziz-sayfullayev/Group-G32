import React from 'react';
import Home from "../Pages/Home/Home";
import Shop from "../Pages/Shop/Shop";
import Product from "../Pages/Product/Product";
import Card from "../Pages/Card/Card";
import LikePages from "../Pages/LikePages/LikePages";
import Accaunt from "../Pages/Accaunt/Accaunt";
import SoatImg from "../Pages/SoatImg/SoatImg";
import NotFaund from "../Pages/NotFaund/NotFaund";
import { Route, Routes } from 'react-router-dom';
function Pages() {
  return (
    <div>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/shop' element={<Shop/>}/>
        <Route path='/product/:id' element={<Product/>}/>
        <Route path='/card' element={<Card/>}/>
        <Route path='/like' element={<LikePages/>}/>
        <Route path='/soatImg' element={<SoatImg/>}/>
        <Route path='/accaunt' element={<Accaunt/>}/>
        <Route path='*' element={<NotFaund/>}/>
      </Routes>
    </div>
  )
}
export default Pages;