import React, { useContext, useState, useRef } from "react";
// Imgs

import icon1 from "../../../Imgs/Home/Section1/icon1.png";
import icon2 from "../../../Imgs/Home/Section1/icon2.png";
import icon3 from "../../../Imgs/Home/Section1/icon3.png";

import star1 from "../../../Imgs/Category/star1.png";
import star2 from "../../../Imgs/Category/star2.png";
import star3 from "../../../Imgs/Category/star3.png";
import star4 from "../../../Imgs/Category/star4.png";
import star5 from "../../../Imgs/Category/star5.png";
import star from "../../../Imgs/Home/Section1/startIcon.png";

import card1 from "../../../Imgs/Home/Section1/imgCard1.png";
import card2 from "../../../Imgs/Home/Section1/imgCard2.png";
import card3 from "../../../Imgs/Home/Section1/imgCard3.png";

import mainCardImg1 from "../../../Imgs/Category/mainCardImg1.png";

import circle4 from "../../../Imgs/Category/circle4.png";
import btmImg from "../../../Imgs/Category/btmImg.png";
// Mui

import Box from "@mui/material/Box";
import Slider from "@mui/material/Slider";

// React icons
import { Pagination, Navigation } from "swiper";

// Swaper
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";

import { Swiper, SwiperSlide } from "swiper/react";

import {
  AiOutlineArrowDown,
  AiOutlineArrowLeft,
  AiOutlineArrowRight,
} from "react-icons/ai";
import { Context } from "../../../Context";

function valuetext(value) {
  return `${value}`;
}
export function CategoryPage() {
  const [top, setTop] = useState([
    {
      img: icon1,
      text: "Reliable Shipping",
    },
    {
      img: icon2,
      text: "You’re Safe With Us",
    },
    {
      img: icon3,
      text: "Best Quality & Pricing",
    },
  ]);

  const [category, setCategory] = useState([
    {
      id: 0,
      name: "Sales",
      num: 12,
      check: false,
    },
    {
      id: 1,
      name: "Cannabis",
      num: 430,
      check: false,
    },
    {
      id: 2,
      name: "Pre-Rolls",
      num: 40,
      check: false,
    },
    {
      id: 3,
      name: "CBD Oil",
      num: 20,
      check: false,
    },
    {
      id: 4,
      name: "Magic Mushrooms",
      num: 34,
      check: false,
    },
    {
      id: 5,
      name: "Extracts",
      num: 26,
      check: false,
    },
    {
      id: 6,
      name: "Edibles",
      num: 32,
      check: false,
    },
    {
      id: 7,
      name: "Vape Pens",
      num: 12,
      check: false,
    },
    {
      id: 8,
      name: "Accessories",
      num: 10,
      check: false,
    },
    {
      id: 9,
      name: "Bath & Body",
      num: 8,
      check: false,
    },
    {
      id: 10,
      name: "Bundles",
      num: 24,
      check: false,
    },
    {
      id: 11,
      name: "Wholesale",
      num: 28,
      check: false,
    },
  ]);

  const [order, setOrder] = useState([
    {
      id: 0,
      name: "Default",
      check: false,
    },
    {
      id: 1,
      name: "Review Count",
      check: false,
    },
    {
      id: 2,
      name: "Popularity",
      check: false,
    },
    {
      id: 3,
      name: "Average Rating",
      check: false,
    },
    {
      id: 4,
      name: "Newness",
      check: false,
    },
    {
      id: 5,
      name: "Price: Low to High",
      check: false,
    },
    {
      id: 6,
      name: "Price: High to Low",
      check: false,
    },
    {
      id: 7,
      name: "Random Products",
      check: false,
    },
    {
      id: 8,
      name: "Product Name",
      check: false,
    },
  ]);

  const [review, setReview] = useState([
    {
      id: 0,
      img: star5,
      check: false,
    },
    {
      id: 1,
      img: star4,
      check: false,
    },
    {
      id: 2,
      img: star3,
      check: false,
    },
    {
      id: 3,
      img: star2,
      check: false,
    },
    {
      id: 4,
      img: star1,
      check: false,
    },
  ]);

  let checkFunc = (item) => {
    setCategory(
      category.map((val) =>
        val.id === item.id
          ? { ...val, check: !val.check }
          : { ...val, check: false }
      )
    );
    setFilterData(
      product.filter((val) =>
        val.category.toLocaleLowerCase().includes(item.name.toLocaleLowerCase())
      )
    );
    setFilterData1(
      product1.filter((val) =>
        val.category.toLocaleLowerCase().includes(item.name.toLocaleLowerCase())
      )
    );
  };

  let checkFunc2 = (id) => {
    setOrder(
      order.map((val) =>
        val.id === id ? { ...val, check: !val.check } : { ...val, check: false }
      )
    );
  };
  let checkFunc3 = (id) => {
    setReview(
      review.map((val) =>
        val.id === id ? { ...val, check: !val.check } : { ...val, check: false }
      )
    );
  };

  const [value, setValue] = React.useState([0, 50000]);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const [product1, setProduct1] = useState([
    {
      id: 0,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "Cannabis",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 300,
      number: 0,
    },
    {
      id: 1,
      name: "Mix And Match Shatter/Budder 28g (4 X 7G)",
      category: "Pre-Rolls",
      star: "4.2",
      img: card2,
      reviews: 188,
      composition: "Indica 70%",
      sale: 42,
      price: 200,
      number: 0,
    },
    {
      id: 2,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "CBD Oil",
      star: "4.6",
      img: card3,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 1500,
      number: 0,
    },
  ]);
  const [product, setProduct] = useState([
    {
      id: 3,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "Magic Mushrooms",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 39200,
      number: 0,
    },
    {
      id: 4,
      name: "Mix And Match Shatter/Budder 28g (4 X 7G)",
      category: "Extracts",
      star: "4.2",
      img: card2,
      reviews: 188,
      composition: "Indica 70%",
      sale: 42,
      price: 4200,
      number: 0,
    },
    {
      id: 5,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "Edibles",
      star: "4.6",
      img: card3,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 8000,
      number: 0,
    },
    {
      id: 6,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "Vape Pens",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 3880,
      number: 0,
    },
    {
      id: 7,
      name: "Mix And Match Shatter/Budder 28g (4 X 7G)",
      category: "Accessories",
      star: "4.2",
      img: card2,
      reviews: 188,
      composition: "Indica 70%",
      sale: 42,
      price: 9200,
      number: 0,
    },
    {
      id: 8,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "Bath & Body",
      star: "4.6",
      img: card3,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 1880,
      number: 0,
    },
  ]);

  const [filterData, setFilterData] = useState(product);
  const [filterData1, setFilterData1] = useState(product1);

  const [open, setOpen] = useState(false);
  let openFunc = () => setOpen(!open);

  let filterFunc = () => {
    setFilterData1(
      product1.filter((val) => {
        if (val.price >= value[0] && val.price <= value[1]) {
          return val;
        }
      })
    );
    setFilterData(
      product.filter((val) => {
        if (val.price >= value[0] && val.price <= value[1]) {
          return val;
        }
      })
    );
  };
  function clearFilterFunc() {
    setFilterData(product);
    setFilterData1(product1);
    setValue([0, 50000]);
    setCategory(category.map((val) => ({ ...val, check: false })));
  }

  let { cart, setCart } = useContext(Context);

  let addCartFunc = (item) => {
    if (cart.filter((elem) => elem.id === item.id).length === 0) {
      localStorage.setItem("localData", JSON.stringify([...cart, item]));
      setCart(JSON.parse(localStorage.getItem("localData")) || []);
    } else {
      alert("This product has been added to the cart!");
    }
  };

  return (
    <div className="CategoryPage">
      <div className="cyTop">
        {top.map((val, i) => (
          <div key={i} className="cyTopContent">
            <div className="cyTopLeft">
              <div className="cyImgBox">
                <img src={val.img} alt="img" />
              </div>
              <h1>{val.text}</h1>
            </div>
            <hr />
          </div>
        ))}
      </div>
      <div className="cyMainSection">
        <div className={open ? "cyMainLeft open" : "cyMainLeft"}>
          <h1>Filters</h1>
          <hr />
          <div className="filterCategory">
            <h1>PRODUCT CATEGORY</h1>
            <div className="cyMainCheck">
              {category.map((val, i) => (
                <div
                  onClick={() => checkFunc(val)}
                  key={i}
                  className="catogorysBox"
                >
                  <button
                    className={val.check ? "cyChexBox active" : "cyChexBox"}
                  >
                    <p className={val.check ? "active" : ""}></p>
                  </button>
                  <h1>{val.name}</h1>
                  <hr />
                  <p>{val.num}</p>
                </div>
              ))}
            </div>
            <hr />
            <h1>FILTER BY PRICE</h1>
            <div className="cyFilterPrice">
              <div className="filterPriceBox">
                <h1>$0</h1>
                <h1>$50,000.00</h1>
              </div>
              <Box sx={{ width: 200 }}>
                <Slider
                  getAriaLabel={() => "Temperature range"}
                  value={value}
                  onChange={handleChange}
                  valueLabelDisplay="auto"
                  getAriaValueText={valuetext}
                  max={50000}
                  color="success"
                  step={50}
                />
              </Box>
              <button onClick={filterFunc}>Apply</button>
            </div>
            <hr />
            <h1>ORDER BY</h1>
            <div className="cyMainCheck">
              {order.map((val, i) => (
                <div
                  onClick={() => checkFunc2(val.id)}
                  key={i}
                  className="catogorysBox"
                >
                  <button
                    className={val.check ? "cyChexBox active" : "cyChexBox"}
                  >
                    <p className={val.check ? "active" : ""}></p>
                  </button>
                  <h1>{val.name}</h1>
                </div>
              ))}
            </div>
            <hr />
            <h1>FILTER BY REVIEWS</h1>
            <div className="cyMainCheck">
              {review.map((val, i) => (
                <div
                  onClick={() => checkFunc3(val.id)}
                  key={i}
                  className="catogorysBox"
                >
                  <button
                    className={val.check ? "cyChexBox active" : "cyChexBox"}
                  >
                    <p className={val.check ? "active" : ""}></p>
                  </button>
                  <img src={val.img} alt="" />
                </div>
              ))}
            </div>
            <hr />
            <button onClick={clearFilterFunc} className="clearFilterBtn">
              {" "}
              Clear Filters
            </button>
          </div>
        </div>
        <div className="cyMainRight">
          <div className="cyMainRightTop">
            <div className="cyMnTpBtns">
              <h1>Shop</h1>
              <div>
                <button onClick={openFunc} className="openFilterBtn">
                  Filter <AiOutlineArrowDown />
                </button>
                <button>
                  Short By Lates <AiOutlineArrowDown />
                </button>
              </div>
            </div>
            <hr />
            <div className="cyMnTpContent">
              <h1>Cannabis</h1>
              <p>
                Here at WestCoastSupply’s “ cannabis section, we showcase the
                best Indica, Hybrid, and Sativa medical cannabis strain
                selections at the best prices online. You can be assured that
                all our strains go through a strict screening process to ensure
                that all your cannabis needs are top-quality. All of our flowers
                are sourced from reputable growers, based in British Columbia,
                Canada. We have hige grade selection comes from growers that
                produce AAAA+ quality cannabis flowers and have many years of
                experience in the cannabis industry. You are guaranteed to be
                receiving high-quality flowers at the best prices online with
                our unbeatable sales!
              </p>
            </div>
            <div className="CardsBox1cy">
              <div className="Cards1">
                {filterData1.length > 0 ? (
                  filterData1.map((val, i) => (
                    <div key={i} className="card">
                      <div className="cardImg">
                        <img src={val.img} alt="img" />
                        <button className="cardSrockBtn">Out Of Stock</button>
                      </div>
                      <h1 className="cardCategory">{val.category}</h1>
                      <div className="cardContet">
                        <h1 className="cardName">{val.name}</h1>
                        <div className="cardClass">
                          <div className="star">
                            <img src={star} alt="img" />
                            {val.star}/5
                            <hr />
                            {val.reviews}
                            <p>Reviews</p>
                          </div>
                          <h1 className="cardComposition">{val.composition}</h1>
                          <div className="priceBox">
                            <p className="salePrice">
                              {val.price - (val.price / 100) * val.sale}$
                            </p>
                            <p className="price">{val.price}$</p>
                          </div>
                        </div>
                        <div className="cardKilo">
                          <p>28g</p>
                          <p>1/2lb</p>
                          <p>1/4lb</p>
                        </div>
                        <button
                          onClick={() => addCartFunc(val)}
                          className="addCartBtn"
                        >
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <h1>No Data...</h1>
                )}
              </div>
            </div>
            <div className="CardsBox2cy">
              <div className="Cards1">
                {filterData.length > 0 ? (
                  filterData.map((val, i) => (
                    <div key={i} className="card">
                      <div className="cardImg">
                        <img src={val.img} alt="img" />
                        <button className="cardSrockBtn">Out Of Stock</button>
                      </div>
                      <h1 className="cardCategory">{val.category}</h1>
                      <div className="cardContet">
                        <h1 className="cardName">{val.name}</h1>
                        <div className="cardClass">
                          <div className="star">
                            <img src={star} alt="img" />
                            {val.star}/5
                            <hr />
                            {val.reviews}
                            <p>Reviews</p>
                          </div>
                          <h1 className="cardComposition">{val.composition}</h1>
                          <div className="priceBox">
                            <p className="salePrice">
                              {val.price - (val.price / 100) * val.sale}$
                            </p>
                            <p className="price">{val.price}$</p>
                          </div>
                        </div>
                        <div className="cardKilo">
                          <p>28g</p>
                          <p>1/2lb</p>
                          <p>1/4lb</p>
                        </div>
                        <button
                          onClick={() => addCartFunc(val)}
                          className="addCartBtn"
                        >
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <h1>No Data...</h1>
                )}
              </div>
            </div>
            <div className="cyMainCard1Right">
              <div className="Left">
                <div className="LeftTop">
                  <p>CONCENTRATES</p>
                  <h1>Mix And Match Shatter/Budder 28g (4 X 7G)</h1>
                </div>
                <div className="LeftList">
                  <div className="star">
                    <img src={star} alt="img" />
                    4.6/5
                    <hr />
                    135
                    <p>Reviews</p>
                  </div>
                </div>
                <div className="cardKilo">
                  <p>28g</p>
                  <p>1/2lb</p>
                  <p>1/4lb</p>
                </div>
                <div className="LeftRow">
                  <button>Add to Cart</button>
                  <div className="lwPrice">
                    $102.00
                    <p>$200.00</p>
                  </div>
                </div>
              </div>
              <div className="Right">
                <Swiper
                  pagination={{
                    type: "bullets",
                  }}
                  navigation={true}
                  modules={[Pagination, Navigation]}
                  className="mySwiper"
                >
                  <SwiperSlide>
                    <img src={mainCardImg1} alt="img" />
                  </SwiperSlide>
                  <SwiperSlide>
                    <img src={card1} alt="img" />
                  </SwiperSlide>
                  <SwiperSlide>
                    <img src={card2} alt="img" />
                  </SwiperSlide>
                  <SwiperSlide>
                    <img src={card3} alt="img" />
                  </SwiperSlide>
                </Swiper>
              </div>
            </div>
            <div className="CardsBox2cy">
              <div className="Cards1">
                {filterData.length > 0 ? (
                  filterData.map((val, i) => (
                    <div key={i} className="card">
                      <div className="cardImg">
                        <img src={val.img} alt="img" />
                        <button className="cardSrockBtn">Out Of Stock</button>
                      </div>
                      <h1 className="cardCategory">{val.category}</h1>
                      <div className="cardContet">
                        <h1 className="cardName">{val.name}</h1>
                        <div className="cardClass">
                          <div className="star">
                            <img src={star} alt="img" />
                            {val.star}/5
                            <hr />
                            {val.reviews}
                            <p>Reviews</p>
                          </div>
                          <h1 className="cardComposition">{val.composition}</h1>
                          <div className="priceBox">
                            <p className="salePrice">
                              {val.price - (val.price / 100) * val.sale}$
                            </p>
                            <p className="price">{val.price}$</p>
                          </div>
                        </div>
                        <div className="cardKilo">
                          <p>28g</p>
                          <p>1/2lb</p>
                          <p>1/4lb</p>
                        </div>
                        <button
                          onClick={() => addCartFunc(val)}
                          className="addCartBtn"
                        >
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <h1>No Data...</h1>
                )}
              </div>
            </div>
            <hr />
            <div className="cyBottom">
              <h1>Showing 1-30 of 393 results</h1>
              <img src={btmImg} alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
