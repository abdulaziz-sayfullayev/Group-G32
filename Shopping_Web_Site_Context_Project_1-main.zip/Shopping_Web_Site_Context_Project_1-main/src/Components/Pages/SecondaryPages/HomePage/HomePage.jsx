import React from 'react'
import { Header } from './HomeSections/Header'
import { Section1 } from './HomeSections/Section1'
import { Section2 } from './HomeSections/Section2'
import { Section3 } from './HomeSections/Section3'

export function HomePage() {
  return (
    <div className='HomePage'>
      <Header/>
      <Section1/>
      <Section2/>
      <Section3/>
    </div>
  )
}
