import React, { useContext, useState } from "react";

// Imgs

import img1 from "../../../Imgs/Home/Section1/imgCard1.png";
import img2 from "../../../Imgs/Home/Section1/imgCard2.png";
import img3 from "../../../Imgs/Home/Section1/imgCard3.png";
import exportIcon from "../../../Imgs/Category/export.png";
import star from "../../../Imgs/Home/Section1/startIcon.png";

import icon1 from "../../../Imgs/Des-on/icon1.png";
import icon2 from "../../../Imgs/Des-on/icon2.png";
import icon3 from "../../../Imgs/Des-on/icon3.png";

import row1 from "../../../Imgs/Des-on/Row1.png";
import row2 from "../../../Imgs/Des-on/Row2.png";

import user1 from "../../../Imgs/Home/Section1/user1.png";
import user2 from "../../../Imgs/Home/Section1/user2.png";

import check from "../../../Imgs/Des-on/check.png";
import card1 from "../../../Imgs/Home/Section1/imgCard1.png";
import card2 from "../../../Imgs/Home/Section1/imgCard2.png";
import card3 from "../../../Imgs/Home/Section1/imgCard3.png";

import button from "../../../Imgs/Des-on/Button.png";

import sot1 from "../../../Imgs/Des-on/Facebook.png";
import sot2 from "../../../Imgs/Des-on/Twitter.png";
import sot3 from "../../../Imgs/Des-on/Whatsapp.png";
import { TextField } from "@mui/material";
// Mui
import Rating from "@mui/material/Rating";

import plus from "../../../Imgs/Des-on/Button+.png";
import { Context } from "../../../Context";
export function DescriptionPage() {
  const [list, setList] = useState([
    {
      id: 0,
      name: "EFFECTS",
      text: "Calming, Creative, Happy, Relaxing, Sleepy, Uplifting",
      img: icon1,
    },
    {
      id: 1,
      name: "MAY RELIEVE",
      text: "Anxiety, Arthritis, Chronic Pain, Depression, Fatigue, Inflammation, Insomnia, Irregular Bowel Movements, Migraines, Mood Swings",
      img: icon2,
    },
    {
      id: 2,
      name: "AROMAS",
      text: "Chemical, Citrus, Earthy, Pungent, Sour",
      img: icon3,
    },
  ]);

  const [lab, setLab] = useState(1);

  function labchangeFunc(number) {
    setLab(number);
  }

  const [product1, setProduct1] = useState([
    {
      id: 9,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 10,
      name: "Mix And Match Shatter/Budder 28g (4 X 7G)",
      category: "CONCENTRATES",
      star: "4.2",
      img: card2,
      reviews: 188,
      composition: "Indica 70%",
      sale: 42,
      price: 200,
      number: 0,
    },
    {
      id: 11,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card2,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 12,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card3,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
  ]);
  const [number, setNumber] = useState(0);

  let plusFunc = () => {
    number < 10 ? setNumber(number + 1) : alert("Max: 10!");
  };
  let minusFunc = () => {
    number > 1 ? setNumber(number - 1) : alert("Min: 1!");
  };

  const [tab, setTab] = useState(1);

  const [input, setInput] = useState({
    id: 0,
    name: "User:",
    data: "January 15, 2023",
    star: 0,
    text: "",
    img: user1,
  });

  const [reviews, setReviews] = useState([
    {
      id: 0,
      img: user1,
      name: "Vikki Starr",
      data: "January 15, 2023",
      star: 4,
      text: "Absolutely love TopShelfBC; affordable on any budget and such fast delivery, straight to my door! I recommend them to all my friends and family for their 420 needs.",
    },
    {
      id: 1,
      img: user2,
      name: "Terry Baskey",
      data: "January 15, 2023",
      star: 5,
      text: "Best damn place to buy your canabis at great prices",
    },
  ]);

  function getValueFunc(e) {
    setInput({
      ...input,
      text: e.target.value,
    });
  }
  function getValueFunc2(e) {
    setInput({
      ...input,
      star: e.target.value,
    });
  }
  let clearInput = () => {
    setInput({
      id: 0,
      name: "User:",
      data: "January 15, 2023",
      star: 0,
      text: "",
      img: user1,
    });
  };

  let sendFunc = () => {
    setReviews([...reviews, { ...input, id: new Date().getTime() }]);
    setReviews([...reviews, { ...input, name: "User:" + input.id }]);
    clearInput();
  };

  const [sot, setSot] = useState([
    {
      name: "Share Via Facebook",
      img: sot1,
      id: 0,
    },
    {
      name: "Share Via Twitter",
      img: sot2,
      id: 1,
    },
    {
      name: "Share Via Whatsapp",
      img: sot3,
      id: 2,
    },
  ]);

  let tabFunc = (id) => setTab(id);

  const [modalOpen, setModalOpen] = useState(false);

  let open2 = () => {
    setModalOpen(!modalOpen);
  };

  let slideImgs = [img1, img2, img3, img2];
  const [slide, setSlide] = useState(0);
  let slideFunc = (id) => {
    setSlide(id);
  };
  let { cart, setCart } = useContext(Context);
  let addCartFunc = (item) => {
    if (cart.filter((val) => val.id === item.id).length === 0) {
      localStorage.setItem("localData", JSON.stringify([...cart, item]));
      setCart(JSON.parse(localStorage.getItem("localData")) || []);
    } else {
      alert("This product has been added to the cart!");
    }
  };
  const [show, setShow] = useState(false);
  let showFunc = () => {
    setShow(!show);
  };
  return (
    <div className="DescriptionPage">
      <div className={modalOpen ? "modalCardBox active" : "modalCardBox"}>
        <div className="imgBoxModal">
          <div className="mainImgBoxml">
            <img src={slideImgs[slide]} alt="img" />
            <button onClick={open2}>
              <img src={exportIcon} alt="img" />
            </button>
          </div>
          <div className="slideImgsdn">
            <div
              className={slide === 0 ? "active" : ""}
              onClick={() => slideFunc(0)}
            >
              <img src={img1} alt="img" />
            </div>
            <div
              className={slide === 1 ? "active" : ""}
              onClick={() => slideFunc(1)}
            >
              <img src={img2} alt="img" />
            </div>
            <div
              className={slide === 2 ? "active" : ""}
              onClick={() => slideFunc(2)}
            >
              <img src={img3} alt="img" />
            </div>
            <div
              className={slide === 3 ? "active" : ""}
              onClick={() => slideFunc(3)}
            >
              <img src={img2} alt="img" />
            </div>
          </div>
        </div>
      </div>
      <div className="DnPageTop">
        <div className="dnLeft">
          <div onClick={open2} className="imgBox">
            <img src={slideImgs[slide]} alt="img" />
            <button>
              <img src={exportIcon} alt="img" />
            </button>
          </div>
          <div className="slideImgsdn">
            <div
              className={slide === 0 ? "active" : ""}
              onClick={() => slideFunc(0)}
            >
              <img src={img1} alt="img" />
            </div>
            <div
              className={slide === 1 ? "active" : ""}
              onClick={() => slideFunc(1)}
            >
              <img src={img2} alt="img" />
            </div>
            <div
              className={slide === 2 ? "active" : ""}
              onClick={() => slideFunc(2)}
            >
              <img src={img3} alt="img" />
            </div>
            <div
              className={slide === 3 ? "active" : ""}
              onClick={() => slideFunc(3)}
            >
              <img src={img2} alt="img" />
            </div>
          </div>
        </div>
        <div className="dnRight">
          <div className="top">
            <p>CONCENTRATES</p>
            <h1>Mix And Match Shatter/Budder 28g (4 X 7G)</h1>
            <div className="topBtnsdn">
              <button>Indica</button>
              <button>Sativa 100%</button>
            </div>
            <div className="price_review">
              <div className="priceBox">
                <p className="salePrice">200$</p>
                <p className="price">120$</p>
              </div>
              <div className="star">
                <img src={star} alt="img" />
                4.6/5
                <hr />
                135
                <p>Reviews</p>
              </div>
            </div>
          </div>
          <div className="list">
            {list.map((val) => (
              <div key={val.id} className="listContentDn">
                <img src={val.img} alt="img" />
                <div className="listTextDn">
                  <h1>{val.name}</h1>
                  <p>{val.text}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="box1dn">
            <h1>DESCRIPTION</h1>
            <p>
              Jungle Diamonds is a slightly indica dominant hybrid strain (60%
              indica/40% sativa) created through crossing the infamous
              Slurricane X Gorilla Glue #4 strains.
            </p>
          </div>
          <hr />
          <div className="box1dn">
            <div className="framedn">
              <div className="leftfeDn">
                <h1>WEIGHT</h1>
                <div className="labsfedn">
                  <p
                    className={lab === 1 ? "active" : ""}
                    onClick={() => labchangeFunc(1)}
                  >
                    28g
                  </p>
                  <p
                    className={lab === 2 ? "active" : ""}
                    onClick={() => labchangeFunc(2)}
                  >
                    1/2lb
                  </p>
                  <p
                    className={lab === 3 ? "active" : ""}
                    onClick={() => labchangeFunc(3)}
                  >
                    1/4lb
                  </p>
                </div>
              </div>
              <div className="leftfeDn">
                <h1>Add Integra Pack</h1>
                <div className="kilofeDn">
                  <div>
                    <input type="checkbox" />
                    <p>4g (+$2.00)</p>
                  </div>
                  <div>
                    <input type="checkbox" />
                    <p>8g (+$3.00)</p>
                  </div>
                </div>
              </div>
            </div>
            <h1 id="h1Dn">
              Purchase this product now and earn{" "}
              <b style={{ color: "#EB2606" }}>80</b> Points!
            </h1>
          </div>
          <div className="mainBoxDn">
            <div className="top">
              <div>
                <h1>
                  Khalifa Kush (AAAA) <b style={{ color: `#9d9ea2,` }}>2x</b>
                </h1>
                <p>$120.00</p>
              </div>
              <div>
                <h1>Add Integra Pack - 4g</h1>
                <p>$2.00</p>
              </div>
            </div>
            <hr />
            <div className="plusMinusBoxDn">
              <div className="plusMinus">
                <button onClick={minusFunc}>-</button>
                <h1>{number}</h1>
                <button onClick={plusFunc}>+</button>
                <hr />
                <p>In Stock</p>
              </div>
              <button onClick={() => addCartFunc(product1[0])}>
                Add to Cart <hr /> ${121 * number}.00
              </button>
            </div>
            <hr />
            <div className="box2dn">
              <h1>
                <img src={check} alt="img" />
                Free Xpress Shipping on orders over{" "}
                <b style={{ color: `#F2BC1B` }}>$149</b>
              </h1>
              <h1>
                <img src={check} alt="img" />
                Order before 12:00pm for same day dispatch
              </h1>
              <h1>
                <img src={check} alt="img" />
                Support & ordering open 7 day a week
              </h1>
            </div>
          </div>
          <hr />
          <div className="btmDnRight">
            <img src={row1} alt="img" />
            <img src={row2} alt="img" />
          </div>
          <hr />
          <div className="mainTabsDn">
            <div className="buttonsTabs">
              <button
                onClick={() => tabFunc(1)}
                className={tab === 1 ? "active" : ""}
              >
                Description
              </button>
              <button
                onClick={() => tabFunc(2)}
                className={tab === 2 ? "active" : ""}
              >
                Reviews <b>(350)</b>
              </button>
              <button
                onClick={() => tabFunc(3)}
                className={tab === 3 ? "active" : ""}
              >
                Refer a Friend
              </button>
            </div>
            <hr />
            <div
              className={tab === 1 ? "descriptionTab active" : "descriptionTab"}
            >
              <h1>
                Jungle Diamonds is a slightly indica dominant hybrid strain (60%
                indica/40% sativa) created through crossing the infamous
                Slurricane X Gorilla Glue #4 strains. Named for its gorgeous
                appearance and breeder, Jungle Diamonds is a favorite of indica
                and hybrid lovers alike thanks to its delicious taste and
                tingly, arousing high. Jungle Diamonds buds have sparkling
                oversized spade-shaped olive green nugs with vivid amber hairs
                and a thick frosty blanket of glittering tiny blue-tinted white
                crystal trichomes. As you pull apart each sticky little nugget,
                aromas of spicy mocha coffee and fruity herbs are released.{" "}
              </h1>
              <h1>
                The flavor is of sweet chocolate with hints of fresh ripe
                berries to it, too. The Jungle Diamonds high is just as
                delicious, with happy effects that will boost the spirits and
                kick negative thoughts and moods to the curb. You’ll feel a
                tingly sense in your body from start to finish that serves to
                remove any aches or pains while leaving you pretty aroused at
                times. This is accompanied by a blissfully unfocused heady lift
                that leaves your head in the clouds without causing sedation.
                With these effects and its pretty high 17-24% THC level, Jungle
                Diamonds is ideal for experienced patients with chronic pain,
                cramps or muscle spasms and appetite loss or nausea.
              </h1>
            </div>
            <div
              style={show ? { overflow: `scroll` } : { overflow: "hidden" }}
              className={tab === 2 ? "reviewsTab active" : "reviewsTab"}
            >
              {reviews.map((val, i) => (
                <div key={i} className="reviewBox">
                  <div className="tabUserBox">
                    <img src={val.img} alt="img" />
                    <h1>{val.name}</h1>
                    <hr />
                    <p>{val.data}</p>
                  </div>
                  <hr />
                  <div className="starBox">
                    <Rating
                      value={val.star}
                      name="half-rating"
                      defaultValue={0}
                      precision={0.5}
                    />
                  </div>
                  <p>{val.text}</p>
                </div>
              ))}
              <button onClick={showFunc}>Show More</button>
              <hr />
              <div className="addReviewBox">
                <h1>Add A Review</h1>
                <div className="ratingBox">
                  <h1>Your rating</h1> :
                  <Rating
                    value={input.star}
                    onChange={getValueFunc2}
                    name="half-feedback"
                    defaultValue={0}
                    precision={0.5}
                  />
                </div>
                <div className="TextBoxRew">
                  <h1>
                    Your Review <b style={{ color: `red` }}>*</b>
                  </h1>
                  <input
                    value={input.text}
                    onChange={getValueFunc}
                    name="text"
                    type="text"
                    className="comentInput"
                    placeholder="Enter your review"
                  />
                </div>
                <button onClick={sendFunc}>Submit</button>
              </div>
            </div>
            <div
              className={tab === 3 ? "referFriendTab active" : "referFriendTab"}
            >
              <div className="top">
                <h1>Referral Program</h1>
                <p>
                  Absolutely love TopShelfBC; affordable on any budget and such
                  fast delivery, straight to my door! I recommend them to all my
                  friends and family for their 420 needs.
                </p>
              </div>
              <hr />
              <div className="referalLinkBox">
                <div>
                  <hr />
                  <div className="linkRef">
                    <h1>Your Referral URL</h1>
                    <p>
                      Referral code is available only to users with at least one
                      order.
                    </p>
                  </div>
                  <button>
                    <img src={button} alt="" />
                  </button>
                </div>
                <div>
                  <hr />
                  <div className="linkRef">
                    <h1>Your Coupon Code to share</h1>
                    <p>
                      Referral code is available only to users with at least one
                      order.
                    </p>
                  </div>
                  <button>
                    <img src={button} alt="" />
                  </button>
                </div>
              </div>
              <hr />
              <div className="sotSetiLink">
                {sot.map((val) => (
                  <button key={val.id}>
                    <img src={val.img} alt="img" />
                    <h1>{val.name}</h1>
                  </button>
                ))}
              </div>
              <h1>Or share via email</h1>
              <div className="emailBOx">
                <div className="left">
                  <h1>Email</h1>
                  <TextField placeholder="Enter your email" color="success" />
                  <TextField
                    value={"johndoe@example.com"}
                    placeholder="Enter your email"
                    color="success"
                  />
                </div>
                <div className="left">
                  <h1>Name</h1>
                  <TextField placeholder="Enter your name" color="success" />
                  <TextField
                    value={"John Doe"}
                    placeholder="Enter your name"
                    color="success"
                  />
                </div>
                <button>
                  <img src={plus} alt="img" />
                </button>
              </div>
              <button>Send Emails</button>
            </div>
          </div>
        </div>
      </div>
      <hr />
      <div className="DnPageBottom">
        <h1>Featured Product</h1>
        <div className="DnCardsBox">
          {product1.map((val, i) => (
            <div key={i} className="card3">
              <div className="cardImg">
                <img src={val.img} alt="img" />
                <button className="cardSrockBtn">Out Of Stock</button>
              </div>
              <h1 className="cardCategory">{val.category}</h1>
              <div className="cardContet">
                <h1 className="cardName">{val.name}</h1>
                <div className="cardClass">
                  <div className="star">
                    <img src={star} alt="img" />
                    {val.star}/5
                    <hr />
                    {val.reviews}
                    <p>Reviews</p>
                  </div>
                  <h1 className="cardComposition">{val.composition}</h1>
                  <div className="priceBox">
                    <p className="salePrice">
                      {val.price - (val.price / 100) * val.sale}$
                    </p>
                    <p className="price">{val.price}$</p>
                  </div>
                </div>
                <div className="cardKilo">
                  <p>28g</p>
                  <p>1/2lb</p>
                  <p>1/4lb</p>
                </div>
                <button onClick={() => addCartFunc(val)} className="addCartBtn">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
