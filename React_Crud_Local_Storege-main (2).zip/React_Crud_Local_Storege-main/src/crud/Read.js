import React, {useEffect, useState}  from "react";
import { useNavigate } from "react-router-dom";
function Read(){
    const add = useNavigate();
    const update = useNavigate();
    const [search,setSearch] = useState("")
    const [readData, setReadData] = useState([])
    useEffect(()=>{
       setInterval(() => {
            if(localStorage.getItem('key')){
                setReadData([...JSON.parse(localStorage.getItem('key'))]);
            }
       }, 500);
    },[]);
    
    const deleFun = (item) => {
        let filterData = [];
        readData.map((post)=> {
            return item.id == post.id ? "":  filterData.push(post)
        });
        localStorage.setItem('key', JSON.stringify(filterData))
    }
    const updateFun = (item) => {
        console.log(item);
        localStorage.setItem('update', JSON.stringify(item))
        update("update");
    }
    return(
        <div className="container">
            <h1>O'qish</h1>
            <input type="text" onChange={(e) => setSearch(e.target.value)} placeholder="search ..." name="" id="" />
            <button onClick={(e)=> add("create")} id="add">Qo'shish</button>
            <table>
                <thead>
                    <tr> 
                        <th>#</th>
                        <th>Ism</th>
                        <th>Xaqida</th>
                        <th>Narx</th>
                        <th>harakat</th>
                    </tr>
                </thead> 
                <tbody>
                    {
                        readData == "" ? <tr> <h1>Malumot topilmadi</h1> </tr> : 
                        readData.filter((item) => {
                            return search.toLowerCase() === "" ? item : item.name.toLowerCase().includes(search)
                          }).map((item, index) => (
                                <tr key={item.id}> 
                                    <th>{index + 1}</th>
                                    <th>{item.name}</th>
                                    <th>{item.status}</th>
                                    <th>{item.yosh}</th>
                                    <th><button onClick={(e)=> deleFun(item)}>O'chirish</button>
                                    <button onClick={(e)=> updateFun(item)}>Yangilash</button>
                                    </th>
                                </tr>
                        ))
                    }
                </tbody>
            </table>
        </div>
    )
}

export default Read;