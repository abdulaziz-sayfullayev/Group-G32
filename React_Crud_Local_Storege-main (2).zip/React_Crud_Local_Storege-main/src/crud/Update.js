import React, {useEffect, useState} from "react";
import { useNavigate } from "react-router-dom";
function Update (){
    const back = useNavigate();
    const [data, setData] = useState({});
    const [alldata, setAllData] = useState([]);
    useEffect(()=> {
        setData(JSON.parse(localStorage.getItem('update')))
        setAllData(JSON.parse(localStorage.getItem('key')))
    }, [])
    const [erdata, setErData] = useState({
        name: "",
        status: "",
        yosh: ""
    })
    const dataSend = (e) => {
        setData({...data,[e.target.name]:e.target.value})
    }
    const sumbitdata = (e) => {
        e.preventDefault();     
        if(data.name == ""){
            setErData({...erdata, name:"Name Xato!"})
        }else
        if(data.status == ""){
            setErData({...erdata, status: "Malumot Xato!"})
        }else
        if(data.yosh == ""){
            setErData({...erdata, yosh: "Narx Xato!"})
        }
        else{
            let filterUpdate = [];
           alldata.map((item) => {
               item.id == data.id ? filterUpdate.push(data) : filterUpdate.push(item)  
           })
           localStorage.setItem('key', JSON.stringify(filterUpdate));
           back('/');
        }
    }
    return(
        <div className="container">
            <form onSubmit={sumbitdata}>
                <h1>Create</h1>
                <button id="back" onClick={(e)=> back('/')}>Chiqish</button>
                <div>
                    <p>Ism</p>
                    <input name="name" type="text" defaultValue={data.name} placeholder={data.name} onChange={dataSend}/>
                </div>
                <div>
                    <p>Xaqida</p>
                    <input type="text" name="status" defaultValue={data.status} placeholder={data.status} onChange={dataSend}/>
                </div>
                <div>
                    <p>Yosh</p>
                    <input type="text" name="yosh" defaultValue={data.yosh} placeholder={data.yosh} onChange={dataSend}/>
                </div>
                <button id="send">Send</button>
            </form>
        </div>
    )
}

export default Update;