import React, {useState} from "react";
import { useNavigate } from "react-router-dom";
function Create (){
    const back = useNavigate();
    let vaqt = new Date();
    const [data, setData] = useState({ 
        id:btoa(vaqt.getMilliseconds() * Math.random() * 100),
        name: "", 
        status: "",
        Narx: "",
    });
    const [erdata, setErData] = useState({
        name: "",
        status: "",
        yosh: ""
    })
    const dataSend = (e) => {
        setData({...data,[e.target.name]:e.target.value})
    }
    const sumbitdata = (e) => {
        e.preventDefault();
        if(data.name == ""){
            setErData({...erdata, name:"Ism bo'lmasa bo'lmaydi"})
            alert("Ism bo'lmasa bo'lmaydi")
        }else
        if(data.status == ""){
            setErData({...erdata, status: "O'ziz xaqida bo'lmasa bo'lmaydi"})
            alert("O'ziz xaqida bo'lmasa bo'lmaydi")
        }else
        if(data.yosh == ""){
            setErData({...erdata, yosh: "Yosh bo'lmasa bo'lmaydi"})
            alert("Yosh bo'lmasa bo'lmaydi");
        }
        else{
            if(localStorage.getItem("key")){
                let dataLS = [...JSON.parse(localStorage.getItem('key'))]
                dataLS.push(data);
                localStorage.setItem("key", JSON.stringify(dataLS))
                back("/");
                setData({...data, id:btoa(vaqt.getMilliseconds() * Math.random() * 1000)})
            }
            else{
                localStorage.setItem("key", JSON.stringify([data]))
                back("/");
                setData({...data, id:btoa(vaqt.getMilliseconds() * Math.random() * 1000)})
            }
        }
    }
    return(
        <div className="container">
            <span className="load"></span>
            <form onSubmit={sumbitdata}>
                <h1>Create</h1>
                <button id="back" onClick={(e)=> back('/')}>Chiqish</button>
                <div>
                    <p>Ism</p>
                    <input name="name" type="text" onChange={dataSend}/>
                </div>
                <div>
                    <p>Xaqida</p>
                    <input type="text" name="status" onChange={dataSend}/>
                </div>
                <div>
                    <p>Yosh</p>
                    <input type="text" name="yosh" onChange={dataSend}/>
                </div>
                <button id="send"> Send</button>
            </form>
        </div>
    )
}

export default Create;