
let countBox = document.querySelector('.countBox');
let CounterPrice = document.querySelector('#total');
const product = [
    {
        id: 0,
        image: `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfdhBWU82h1enjIwBITSsjKL5yInkR9-hDai9-RPeL1mN4BxfsuCOngCJ1xKopA0t1Mdk&usqp=CAU`,
        title: "Fudboolka A1",
        price: 3,
    },
    {
        id: 1,
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTuVM0FT72IZ0EFsRu54fVgZCvG-VlX5PwHQ&usqp=CAU",
        title: "Fudboolka dwdw 33 wswd",
        price: 4,
    },
    {
        id: 2,
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2BYubZSdrJdXaClplX01pmeMdjRCuiGAbpF2r-T_ACl0CvLG7WLJdjGuShupTn2XJrqQ&usqp=CAU",
        title: "Fudboolka efef 64 wswd",
        price: 6,
    },
    {
        id: 3,
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnx5lSmIerntPq03NWjUzwu_BmZzG8Ra-cIrpV1MZvskbxY3W2frkJjCETz1qWYkFnn1o&usqp=CAU",
        title: "Fudboolka f3f f3 wswd",
        price: 8,
    },
    {
        id: 4,
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-7G-lq_K6ysfPWOd3MKvamJdNcRu6lAHAcg&usqp=CAU",
        title: "Fudboolka ASXDWM 23 wswd",
        price: 10,
    },
]
var cart = [];
document.getElementById("root").innerHTML = product.map((item, index) => {
    var { image, title, price } = item;
    return (`<div class="box">
        <div class="img-box">
            <img class="images" src=${image}/>
        </div>
            <div class="bottom">
            <p>${title}</p>
            <h2>${price}.00</h2> <button onclick=addtocart(${index}) > add to cart</button> 
            </div>
        </div>
    `)
}).join("");
function addtocart(a) {
    if (cart.filter(item => item.id === product[a].id).length === 0) {
        cart.push({ ...product[a] });
        CartFunction();
        countInner();
        counterPrice()
    }
    else {
        alert('bu mahsulot mavjud')
    }
}
function CartFunction() {
    if (cart.length == 0) {
        document.querySelector(".cartItem").innerHTML = "You cart is empy ";
    }
    else {
        document.querySelector(".cartItem").innerHTML = cart.map((items, indexDelete) => {
            var { image, title, price } = items;
            return (`<div class="s">
            <div class="img-box">
                <img class="images" src=${image}/>
            </div>
                <div class="bottom">
                <p>${title}</p>
                <h2>${price}.00</h2> <button onclick=deleteFuntion(${indexDelete}) >Delete</button> 
                </div>
            </div>
        `)
        }).join("")
    }
}
CartFunction()
function countInner() {
    if (cart.length > 0) {
        countBox.innerHTML = `<p id="count"> ${cart.length} </p>`
    }
    else {
        countBox.innerHTML = ''
    }
}
countInner()
function deleteFuntion(b) {
    cart.splice(b, 1);
    CartFunction();
    countInner();
    counterPrice()
}
deleteFuntion();
function counterPrice(){
        CounterPrice.innerHTML = `<p>$ ${cart.reduce((a, b) => (a + b.price),0).toFixed(2)}</p>`
}
counterPrice()