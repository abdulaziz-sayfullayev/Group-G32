import React from "react";
// import Rasm from "../assets/images/Rasm.jpg";
import "../styles/Cotact.css"
const Contact = () => {
  return <div>
    <div className="common__section1"></div>
  </div>
};

export default Contact;
