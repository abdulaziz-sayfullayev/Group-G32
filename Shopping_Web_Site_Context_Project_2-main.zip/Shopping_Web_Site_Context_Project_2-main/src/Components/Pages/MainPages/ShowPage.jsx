import React from 'react'

import { Routes , Route } from "react-router-dom"
import { HomePage } from '../SecondaryPages/HomePage/HomePage'
import { CategoryPage } from '../SecondaryPages/CategoryPage/CategoryPage'
import { DescriptionPage } from '../SecondaryPages/DescriptionPage/DescriptionPage'
import { CartPage } from '../SecondaryPages/CartPage'

export function ShowPage() {
  return (
    <div className='ShowPage'>
        <Routes>
          <Route path='/' element={<HomePage/>}/>
          <Route path='/categorypage' element={<CategoryPage/>}/>
          <Route path='/description' element={<DescriptionPage/>}/>
          <Route path='/cartpage' element={<CartPage/>}/>
        </Routes>
    </div>
  )
}
