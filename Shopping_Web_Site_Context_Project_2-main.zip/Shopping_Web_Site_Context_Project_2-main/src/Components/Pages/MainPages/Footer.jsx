import React from "react";

// Ims

import logo from "../../Imgs/Home/Footer/Logo.png";

import card1 from "../../Imgs/Home/Footer/img1.png";
import card2 from "../../Imgs/Home/Footer/img2.png";
import card3 from "../../Imgs/Home/Footer/img3.png";
import card4 from "../../Imgs/Home/Footer/img4.png";

export function Footer() {
  return (
    <div className="Footer">
      <div className="ftrBox">
        <div className="ftrBoxContent">
          <h1>UNLOCK 20% OFF YOUR FIRST ORDER</h1>
          <p>Reveal coupon code by entering your email</p>
        </div>
        <hr />
        <div className="ftrInputBox">
          <input type="text" placeholder="Email Address" className="ftrInput" />
          <button>Reveal coupon</button>
        </div>
      </div>
      <div className="ftrBtm">
        <div className="ftrBtmLeft">
          <img src={logo} alt="img" />
          <p>
            #1 Canadian top rated online dispensary that meets the customers
            needs in every single medical marijuana aspect. The team here at
            TopShelfBC is heavily involved in the Canadian cannabis industry for
            over 15 years. We strive to provide the top quality products,
            service and care at the lowest prices you’ll ever find.
          </p>
        </div>
        <div className="ftrBtmCenter">
          <div className="firstContent">
            <h1>QUICK LINK</h1>
            <div className="ftrPs2">
              <div className="ftrContenLeft">
                <p>Track Your Order</p>
                <p>Shop All</p>
                <p>Flower</p>
                <p>Edibles</p>
                <p>Concentrates</p>
                <p>Refunds</p>
              </div>
              <div className="ftrContenLeft">
                <p>Mushrooms</p>
                <p>Promotions / Bundles</p>
                <p>Support</p>
                <p>Reward</p>
                <p>Blog</p>
                <p>Shipping Faq</p>
              </div>
            </div>
          </div>
          <div className="firstContent">
            <h1>CONTACT US</h1>
            <p>info@topshelfbc.cc</p>
          </div>
          <div className="firstContent">
            <h1>MORE</h1>
            <div className="ftrPs">
              <div className="ftrContenLeft">
                <p>Buy weed online in Canada</p>
                <p>Buy weed online in New Brunswick</p>
                <p>Buy weed online in Prince Edward Island</p>
                <p>Buy weed online in Northwest Territories</p>
                <p>Buy weed online in Saskatchewan</p>
              </div>
              <div className="ftrContenLeft">
                <p>Buy weed online in Manitoba</p>
                <p>Buy weed online in Quitebec</p>
                <p>Buy weed online in British Columbia</p>
                <p>Buy weed online in Ontario</p>
                <p>Buy weed online in Alberta</p>
              </div>
            </div>
          </div>
          <div className="bankCards">
            <img src={card1} alt="img" />
            <img src={card2} alt="img" />
            <img src={card3} alt="img" />
            <img src={card4} alt="img" />
          </div>
        </div>
        <div className="ftrBtmRight"></div>
      </div>
      <hr />
      <div className="ftrBottom">
        <h1>© 2022 Top Shelf BC. All Rights Reserved. </h1>
        <p>
          <b>Out Of Stock</b>
          <b>Privacy Policy</b>
          <b>Terms & Conditions</b>
        </p>
      </div>
      <i className="powerBy">Power By Muzaffar | 19.05.2023</i>
    </div>
  );
}
