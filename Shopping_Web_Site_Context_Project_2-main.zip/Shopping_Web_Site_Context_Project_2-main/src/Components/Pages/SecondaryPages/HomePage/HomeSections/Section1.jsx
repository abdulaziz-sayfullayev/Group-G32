import React, { useContext, useState } from "react";

// Imgs
import icon1 from "../../../../Imgs/Home/Section1/icon1.png";
import icon2 from "../../../../Imgs/Home/Section1/icon2.png";
import icon3 from "../../../../Imgs/Home/Section1/icon3.png";

// Cards img
import img1 from "../../../../Imgs/Home/Section1/cardImg1.png";
import card1 from "../../../../Imgs/Home/Section1/imgCard1.png";
import card2 from "../../../../Imgs/Home/Section1/imgCard2.png";
import card3 from "../../../../Imgs/Home/Section1/imgCard3.png";
import star from "../../../../Imgs/Home/Section1/startIcon.png";
import whiteStar from "../../../../Imgs/Home/Section1/whiteStar.png";

import googleLogo from "../../../../Imgs/Home/Section1/googleLogo.png";

import user1 from "../../../../Imgs/Home/Section1/user1.png";
import user2 from "../../../../Imgs/Home/Section1/user2.png";
import user3 from "../../../../Imgs/Home/Section1/user3.png";

import card3Img1 from "../../../../Imgs/Home/Header/hmImg1.png";
import card3Img2 from "../../../../Imgs/Home/Header/hmImg2.png";

import vector from "../../../../Imgs/Home/Section1/Vector.png";
import { Context } from "../../../../Context";

// import required modules

export function Section1() {
  const [activeFilter, setActiveFilter] = useState(0);
  let { cart, setCart } = useContext(Context);
  let addCartFunc = (item) => {
    if (cart.filter((elem) => elem.id === item.id).length === 0) {
      localStorage.setItem("localData", JSON.stringify([...cart, item]));
      setCart(JSON.parse(localStorage.getItem("localData")) || []);
    } else {
      alert("This product has been added to the cart!");
    }
  };

  const [product, setProduct] = useState([
    {
      id: 13,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 14,
      name: "Mix And Match Shatter/Budder 28g (4 X 7G)",
      category: "CONCENTRATES",
      star: "4.2",
      img: card2,
      reviews: 188,
      composition: "Indica 70%",
      sale: 42,
      price: 200,
      number: 0,
    },
    {
      id: 15,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
  ]);

  const [users, serUsers] = useState([
    {
      name: "Vikki Starr",
      content:
        "Absolutely love TopShelfBC; affordable on any budget and such fast delivery, straight to my door! I recommend them to all my friends and family for their 420 needs.",
      img: user1,
      dataAdd: "January 15, 2023",
      stars: 4,
    },
    {
      name: "Terry Baskey",
      content: "Best damn place to buy your canabis at great prices",
      img: user2,
      dataAdd: "January 15, 2023",
      stars: 5,
    },
    {
      name: "Terry Baskey",
      content: "Best damn place to buy your canabis at great prices",
      img: user3,
      dataAdd: "January 15, 2023",
      stars: 4,
    },
  ]);
  const [product1, setProduct1] = useState([
    {
      id: 16,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 17,
      name: "Mix And Match Shatter/Budder 28g (4 X 7G)",
      category: "CONCENTRATE",
      star: "4.2",
      img: card2,
      reviews: 188,
      composition: "Indica 70%",
      sale: 42,
      price: 200,
      number: 0,
    },
    {
      id: 18,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "MUSHROOM",
      star: "4.6",
      img: card2,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 19,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "EDIBLE",
      star: "4.6",
      img: card2,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 20,
      name: "Mix And Match Shatter/Budder 28g (4 X 7G)",
      category: "CONCENTRATE",
      star: "4.2",
      img: card3,
      reviews: 188,
      composition: "Indica 70%",
      sale: 42,
      price: 200,
      number: 0,
    },
    {
      id: 21,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card3Img1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 22,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "FLOWER",
      star: "4.6",
      img: card3Img2,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
    {
      id: 23,
      name: "2 Oz Deal Watermelon Zkittles + Purple Gushers",
      category: "EDIBLE",
      star: "4.6",
      img: card1,
      reviews: 135,
      composition: "Sativa 100%",
      sale: 10,
      price: 80,
      number: 0,
    },
  ]);
  const [filter, setFilter] = useState([
    {
      id: 0,
      name: "Shop All Weed",
      active: false,
    },
    {
      id: 1,
      name: "Mushroom",
      active: false,
    },
    {
      id: 2,
      name: "Concentrate",
      active: false,
    },
    {
      id: 3,
      name: "Edible",
      active: false,
    },
    {
      id: 4,
      name: "Flower",
      active: false,
    },
  ]);

  let filterFunc = (id, i) => {
    setData1(
      filter[i].name === "Shop All Weed"
        ? product1
        : product1.filter(
            (val) =>
              val.category.toLocaleLowerCase() ===
              filter[i].name.toLocaleLowerCase()
          )
    );
    setActiveFilter(i);
  };

  const [filData1, setData1] = useState(product1);

  return (
    <div className="Section1">
      <div className="sec1TextBox">
        <div className="sec1Text">
          <div className="sec1Icon">
            <img src={icon1} alt="img" />
          </div>
          <span>
            <h1>Reliable Shipping</h1>
            <p>
              Green Society provides Canada Post Xpress Shipping right to your
              doorstep! You can also opt in for shipping insurance. For orders
              over $149, shipping is free!
            </p>
          </span>
        </div>
        <div className="sec1Text">
          <div className="sec1Icon">
            <img src={icon2} alt="img" />
          </div>
          <span>
            <h1>You’re Safe With Us</h1>
            <p>
              Our secure payment system accepts the most common forms of
              payments making the checkout process quicker! The payments we
              accept are debit, all major credit cards, and cryptocurrency.
            </p>
          </span>
        </div>
        <div className="sec1Text">
          <div className="sec1Icon">
            <img src={icon3} alt="img" />
          </div>
          <span>
            <h1>Best Quality & Pricing</h1>
            <p>
              Here at Green Society, we take pride in the quality of our
              products and service. Our prices are set to ensure you receive
              your medication at a reasonable price and safely
            </p>
          </span>
        </div>
      </div>
      <div className="sec1CardBox1">
        <h1>BEST DISPENSARY TO BUY WEED ONLINE IN CANADA</h1>
        <div className="sec1CardBox1Btns">
          <button className="active">Best Sellers</button>
          <button>Bundles & Promotions</button>
          <button>On Sale</button>
        </div>
        <div className="sec1Cards1">
          <div className="sec1MainCard">
            <img src={img1} alt="img" />
            <div className="mainCardContent">
              <h1>Shop our Best Sellers</h1>
              <p>
                Lorem ipsum dolor sit amet consectetur. Ullamcorper ipsum varius
                lorem blandit lectus magnis feugiat.{" "}
              </p>
              <button>View All</button>
            </div>
          </div>
          <div className="sec1Cards1Cards">
            {product.map((val, i) => (
              <div key={i} className="card">
                <div className="cardImg">
                  <img src={val.img} alt="img" />
                  <button className="cardSrockBtn">Out Of Stock</button>
                </div>
                <h1 className="cardCategory">{val.category}</h1>
                <div className="cardContet">
                  <h1 className="cardName">{val.name}</h1>
                  <div className="cardClass">
                    <div className="star">
                      <img src={star} alt="img" />
                      {val.star}/5
                      <hr />
                      {val.reviews}
                      <p>Reviews</p>
                    </div>
                    <h1 className="cardComposition">{val.composition}</h1>
                    <div className="priceBox">
                      <p className="salePrice">
                        {val.price - (val.price / 100) * val.sale}$
                      </p>
                      <p className="price">{val.price}$</p>
                    </div>
                  </div>
                  <div className="cardKilo">
                    <p>28g</p>
                    <p>1/2lb</p>
                    <p>1/4lb</p>
                  </div>
                  <button
                    onClick={() => addCartFunc(val)}
                    className="addCartBtn"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="sec1Cards2">
          <h1>CUSTOMER TESTIMONIALS</h1>
          <div className="sec1Cards2Cards">
            <div className="sec1MainCard2">
              <h1 className="mainTextCard2">
                VOTED BEST ONLINE DISPENSARY IN CANADA
              </h1>
              <hr />
              <img className="googleLogo" src={googleLogo} alt="img" />
              <div className="mainCard2Content">
                <h1>EXELLENCET</h1>
                <div>
                  <div className="star5Card2">
                    <img src={star} alt="img" />
                    <img src={star} alt="img" />
                    <img src={star} alt="img" />
                    <img src={star} alt="img" />
                    <img src={star} alt="img" />
                  </div>
                  <hr />
                  <p>
                    on 135 <span>Reviews</span>
                  </p>
                </div>
              </div>
            </div>
            {users.map((val, i) => (
              <div key={i} className="card2">
                <div className="userBoxCard2">
                  <img src={val.img} alt="" />
                  <h1 className="nameUserCard2">{val.name}</h1>
                </div>
                <hr />
                <div className="card2Content">
                  <div className="card2Star5">
                    <img src={star} alt="img" />
                    <img src={star} alt="img" />
                    <img src={star} alt="img" />
                    <img src={star} alt="img" />
                    <img src={whiteStar} alt="img" />
                  </div>
                  <p>{val.content}</p>
                </div>
                <p className="addDataUser">{val.dataAdd}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="sec1Cards3">
          <h1>CHOOSE YOUR WEED</h1>
          <div className="filterBoxCards3">
            <h1>Filter by Interest</h1>
            {filter.map((val, i) => (
              <button
                key={val.id}
                style={{ color: activeFilter === i ? "red" : "" }}
                onClick={() => filterFunc(val.id, i)}
              >
                {val.name}
              </button>
            ))}
          </div>
          <div className="cardsBoxCard3">
            {filData1.map((val, i) => (
              <div key={i} className="card3">
                <div className="cardImg">
                  <img src={val.img} alt="img" />
                  <button className="cardSrockBtn">Out Of Stock</button>
                </div>
                <h1 className="cardCategory">{val.category}</h1>
                <div className="cardContet">
                  <h1 className="cardName">{val.name}</h1>
                  <div className="cardClass">
                    <div className="star">
                      <img src={star} alt="img" />
                      {val.star}/5
                      <hr />
                      {val.reviews}
                      <p>Reviews</p>
                    </div>
                    <h1 className="cardComposition">{val.composition}</h1>
                    <div className="priceBox">
                      <p className="salePrice">
                        {val.price - (val.price / 100) * val.sale}$
                      </p>
                      <p className="price">{val.price}$</p>
                    </div>
                  </div>
                  <div className="cardKilo">
                    <p>28g</p>
                    <p>1/2lb</p>
                    <p>1/4lb</p>
                  </div>
                  <button
                    onClick={() => addCartFunc(val)}
                    className="addCartBtn"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="sec1End">
            <img src={vector} alt="img" />
            <div className="bgSec1End"></div>
            <div className="sec1EndLeft">
              <h1>REFER A FRIENDS</h1>
              <p>
                And get <span>$30!</span>
              </p>
            </div>
            <div className="sec1EndRight">
              <button>Refer Here</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
