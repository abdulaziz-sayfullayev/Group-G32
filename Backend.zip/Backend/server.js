require('dotenv').config()
// port = process.env.PORT;
// BaseUrl = process.env.BASE_URL;
// console.log(port);
// // console.log(BaseUrl);
const exepress = require("express")
const mongoos = require('mongoose')
const workoutRoutes = require('./routes/workouts')
const app = exepress();
app.use(exepress.json())
app.use((req,res,next)=>{
    console.log(req.path,req.method);
    next()
})
app.use("/api/workouts",workoutRoutes)
// ochirib tashlandi pasdagi
// app.get('/', (req, res) => {
//     res.json({ mssg: "Welcomwe Abdulazizbek" })
// })
// connect to db
mongoos.connect(process.env.MONG_URL)
    .then(()=>{
        app.listen(process.env.PORT, () => {
            console.log('connected to db & listening on port', process.env.PORT);
        })
    })
    .catch((error)=>{
        console.log(error)
    })
// process.env